﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Toll_Calculator_AFRY.Refactored_Classes.Model;

namespace Toll_Calculator_AFRY.Refactored_Classes
{
    class Program
    {
        static void Main(string[] args)
        {
            TollCalculator Taxcalc = new TollCalculator();
            // Creating Object of Car Interface 
            Car Obj_Car = new Car();

            DateTime[] arr_dt = new DateTime[]  { new DateTime(2013, 02, 1, 15,35,05)  };

            //if valid, it will return amount of tax according to Date and Time;
            string str_Collect_Tax, str_Tax = string.Empty;
            try
            {
                str_Collect_Tax = System.Convert.ToString(Taxcalc.GetTax(Obj_Car, arr_dt));
                Console.WriteLine(str_Collect_Tax);
            }
            catch (Exception ex)
            {
                Console.WriteLine(" Program : Some error occured in code for Single date time " + ex.Message.ToString());
                // we can save the error or display according to requirement 
            }

            //Rule :Single Charge Rule Applied;
            //A vehicle that paasing Several tolling stations with in 60 Mins in Only Taxed Once.
            //The amount that must be paid highest one.

            //DateTime[] arr_dates_Time = new DateTime[]
            //    {
            //    new DateTime(2013, 02, 1, 15,22,33), //13
            //    new DateTime(2013, 02, 1, 15,35,35)  //18
            //    };


            //Rule : The Maximum anount per day and vechicle is 60 SEK

            DateTime[] arr_dates_Time = new DateTime[]
            {
                        new DateTime(2013, 02, 1, 06,02,33),//08
                        new DateTime(2013, 02, 1, 07,05,35),//18
                        new DateTime(2013, 02, 1, 08,10,33),//13
                        new DateTime(2013, 02, 1, 12,35,35),//08
                        new DateTime(2013, 02, 1, 14,31,33),//08
                        new DateTime(2013, 02, 1, 15,35,35),//18
                        new DateTime(2013, 02, 1, 17,35,35) //13
            };

            try
            {
                    str_Tax = System.Convert.ToString(Taxcalc.GetTax(Obj_Car, arr_dates_Time));

            }
            catch(Exception ex)
            {
                Console.WriteLine(" Program : Some error occured in code for multiple date time " + ex.Message.ToString());
                // we can save the error or display according to requirement 
            }
            Console.WriteLine(str_Tax);
            Console.ReadLine();
        }
   
    }
}
