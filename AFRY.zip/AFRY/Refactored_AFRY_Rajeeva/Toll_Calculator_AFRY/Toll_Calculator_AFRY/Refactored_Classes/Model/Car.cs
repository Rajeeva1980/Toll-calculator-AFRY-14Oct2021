﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Toll_Calculator_AFRY.Refactored_Classes.Model
{
    public class Car : Vehicle
    {
        public String GetVehicleType()
        {
            return "Car";
        }
    }
}
