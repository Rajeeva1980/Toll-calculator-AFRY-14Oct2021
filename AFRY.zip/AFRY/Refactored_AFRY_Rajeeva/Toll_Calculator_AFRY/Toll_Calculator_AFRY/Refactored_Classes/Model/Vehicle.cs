﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Toll_Calculator_AFRY.Refactored_Classes.Model
{
    public interface Vehicle
    {
        String GetVehicleType();
    }
}
