﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Toll_Calculator_AFRY.Refactored_Classes.Model;

namespace Toll_Calculator_AFRY.Refactored_Classes
{
    public class TollCalculator : FeeCalculator
    {

        /**
         * Calculate the total toll fee for one day         
         * @param vehicle - the vehicle
         * @param dates   - date and time of all passes on one day
         * @return - the total toll fee for that day
         */

        public int GetTax(Vehicle vehicle, DateTime[] dates)
        {
            DateTime intervalStart = dates[0];
            int totalFee = 0;
            try
            {
                foreach (DateTime date in dates)
                {
                    int nextFee = GetTollFee(date, vehicle);
                    int tempFee = GetTollFee(intervalStart, vehicle);
                    ///Start : Change in Code for Time difference
                    TimeSpan ts = date - intervalStart;
                    long diffInMillies = (long)ts.TotalMilliseconds;
                    ///long diffInMillies = date.Millisecond - intervalStart.Millisecond;
                    ///End : Change in Code for Time difference

                    long minutes = diffInMillies / 1000 / 60;

                    if (minutes <= 60)
                    {
                        if (totalFee > 0) totalFee -= tempFee;
                        if (nextFee >= tempFee) tempFee = nextFee;
                        totalFee += tempFee;
                    }
                    else
                    {
                        totalFee += nextFee;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(" Toll Calculator class : Some error occured in code for Get Tax Method " + ex.Message.ToString());
                // we can save the error or display according to requirement 
            }
            if (totalFee > 60) totalFee = 60;
                return totalFee;

        }
    }
}
