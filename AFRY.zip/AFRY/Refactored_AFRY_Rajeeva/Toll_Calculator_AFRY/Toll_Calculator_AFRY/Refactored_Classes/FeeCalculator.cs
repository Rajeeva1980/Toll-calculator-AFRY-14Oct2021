﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Toll_Calculator_AFRY.Refactored_Classes.Model;

namespace Toll_Calculator_AFRY.Refactored_Classes
{
    public class FeeCalculator : TollFreeValidation
    {
        public int GetTollFee(DateTime date, Vehicle vehicle)
        {
            try
            {
                if (IsTollFreeDate(date) || IsTollFreeVehicle(vehicle)) return 0;
            }
            catch (Exception ex)
            {
                Console.WriteLine(" Fee Calculator class : Some error occured in code for Get toll fee Method " + ex.Message.ToString());
                // we can save the error or display according to requirement 
            }

            int hour = date.Hour;
            int minute = date.Minute;

            if (hour == 6 && minute >= 0 && minute <= 29) return 8;
            else if (hour == 6 && minute >= 30 && minute <= 59) return 13;
            else if (hour == 7 && minute >= 0 && minute <= 59) return 18;
            else if (hour == 8 && minute >= 0 && minute <= 29) return 13;
            else if (hour >= 8 && hour <= 14 && minute >= 30 && minute <= 59) return 8;
            else if (hour == 15 && minute >= 0 && minute <= 29) return 13;
            else if (hour == 15 && minute >= 0 || hour == 16 && minute <= 59) return 18;
            else if (hour == 17 && minute >= 0 && minute <= 59) return 13;
            else if (hour == 18 && minute >= 0 && minute <= 29) return 8;
            else return 0;
        }
    }
}
