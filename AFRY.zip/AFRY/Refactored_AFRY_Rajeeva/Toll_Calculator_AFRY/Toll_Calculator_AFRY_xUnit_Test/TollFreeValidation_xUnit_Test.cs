﻿using System;
using System.Collections.Generic;
using System.Text;
using Xunit;
using Toll_Calculator_AFRY.Refactored_Classes.Model;
using Toll_Calculator_AFRY.Refactored_Classes;

namespace Toll_Calculator_AFRY_xUnit_Test
{
    public class TollFreeValidation_xUnit_Test
    {
        [Theory(DisplayName = " verifying Toll Free Method")]
        [InlineData("02-02-2013 06:05:05", true)] // Saturday
        [InlineData("02-03-2013 06:05:05", true)] // Saturday
        [InlineData("03-07-2013 06:05:05", true)] // July //DD/mm/yyyy
        [InlineData("08-05-2013 06:05:05", true)] // Day before public Holiday //DD/mm/yyyy
        [InlineData("09-05-2013 06:05:05", true)] // public Holiday //DD/mm/yyyy
        [InlineData("01-02-2013 06:45:05", false)] // Normal Days

        public void Test_TollFreeDate_Method(string strdt, bool expected)
        {
            // Arrange
            TollFreeValidation t_Free = new TollFreeValidation();
            // Act
            bool toll_Free = t_Free.IsTollFreeDate(Convert.ToDateTime(strdt));
            // Assert
            Assert.Equal(expected, toll_Free);
        }        
    }
}
