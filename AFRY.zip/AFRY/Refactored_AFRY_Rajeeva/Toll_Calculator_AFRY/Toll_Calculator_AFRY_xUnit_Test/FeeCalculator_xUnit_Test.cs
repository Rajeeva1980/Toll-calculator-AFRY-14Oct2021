﻿using System;
using System.Collections.Generic;
using System.Text;
using Xunit;
using Toll_Calculator_AFRY.Refactored_Classes.Model;
using Toll_Calculator_AFRY.Refactored_Classes;

namespace Toll_Calculator_AFRY_xUnit_Test
{
    public class FeeCalculator_xUnit_Test
    {
        [Theory (DisplayName =" verifying Toll Method for charges")]
        [InlineData("01-02-2013 06:05:05", 8)] 
        [InlineData("01-02-2013 06:45:05", 13)]
        [InlineData("01-02-2013 07:15:05", 18)]
        [InlineData("01-02-2013 08:15:33", 13)]
        [InlineData("01-02-2013 08:35:33", 8)]
        [InlineData("01-02-2013 15:15:33", 13)]
        [InlineData("01-02-2013 15:35:33", 18)]
        [InlineData("01-02-2013 15:22:33", 13)]
        public void Test_GetTollFee_Method(string input_Date, int expected)
        {
            // Arrange
            FeeCalculator FeeCalc = new FeeCalculator();
            // Creating Object of Car Interface 
            Car Obj_Car = new Car();
            //// Input of Date and Vehicle 
            // Act
            int toll_Fee = FeeCalc.GetTollFee(Convert.ToDateTime(input_Date), Obj_Car);
            // Assert
            Assert.Equal(expected, toll_Fee);
        }
    }
}
