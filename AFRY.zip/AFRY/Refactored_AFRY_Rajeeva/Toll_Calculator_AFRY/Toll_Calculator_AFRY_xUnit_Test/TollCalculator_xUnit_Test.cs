﻿using System;
using System.Collections.Generic;
using System.Text;
using Xunit;
using Toll_Calculator_AFRY.Refactored_Classes.Model;
using Toll_Calculator_AFRY.Refactored_Classes;
using Xunit.Extensions;

namespace Toll_Calculator_AFRY_xUnit_Test
{
    public class TollCalculator_xUnit_Test
    {
        [Theory(DisplayName = " verifying Toll Calculator Method")]
        [MemberData(nameof(Obj_Dates))]
        public void Test_TollCalculator_Method(DateTime[] strdt, int expected)
        {
            // Arrange
            TollCalculator toll_tax = new TollCalculator();
            // Creating Object of Car Interface 
            Car Obj_Car = new Car();
            // Act
            int toll_Tax_Calc = toll_tax.GetTax(Obj_Car, strdt);
            // Assert
            Assert.Equal(expected, toll_Tax_Calc);
        }

        public static IEnumerable<object[]> Obj_Dates =>
         new List<object[]>
         {
            new object[] { new DateTime[]
            {
            new DateTime(2013, 02, 1, 15,22,33), //13
            new DateTime(2013, 02, 1, 15,35,35)  //18
            }, 18 }
         
            };

    }
}
